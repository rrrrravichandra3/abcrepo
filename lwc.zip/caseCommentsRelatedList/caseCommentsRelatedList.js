import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getCaseCommentRecords from '@salesforce/apex/CaseRelatedListController.getRecords';

const actions = [
    { label: 'Edit', name: 'edit' },
    { label: 'Delete', name: 'delete' }
];

const columns = [
    {
        label: 'User',
        fieldName: 'UserUrl',
        type: 'url',
        typeAttributes: { label: { fieldName: 'Name' }, target: '_top' },
        cellAttributes: { iconName: 'utility:user' },
        hideDefaultActions: true
    },
    {
        label: 'Public',
        fieldName: 'IsPublished',
        type: 'boolean',
        hideDefaultActions: true
    },
    {
        label: 'Last Modified Date',
        fieldName: 'LastModifiedDate',
        type: 'date',
        typeAttributes: {
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            year: 'numeric'
        },
        hideDefaultActions: true
    },
    {
        label: 'Comment',
        fieldName: 'CommentBody',
        type: 'textarea',
        hideDefaultActions: true
    },
    {
        type: 'action',
        typeAttributes: { rowActions: actions },
        hideDefaultActions: true
    }
];

export default class CaseCommentsRelatedList extends NavigationMixin(
    LightningElement
) {
    title;
    @api recordId;
    records = [];
    showRelatedList = false;
    columns = columns;
    numberOfRecords = 6;
    get hasRecords() {
        return this.records != null && this.records.length;
    }
    connectedCallback() {
        this.showRelatedList = this.recordId != null;
        this.fetchCaseComments();
    }
    fetchCaseComments() {
        getCaseCommentRecords({ recordId: this.recordId })
            .then((result) => {
                this.records = result.map((el) => {
                    return {
                        Id: el.Id,
                        Name: el.CreatedBy.Name,
                        CommentBody: el.CommentBody,
                        IsPublished: el.IsPublished,
                        LastModifiedDate: el.LastModifiedDate,
                        UserUrl: '/' + el.CreatedBy.Id
                    };
                });
                if (this.records.length > this.numberOfRecords) {
                    this.title = `Case Comments (${this.numberOfRecords}+)`;
                    this.records.splice(
                        this.numberOfRecords,
                        this.records.length - 1
                    );
                } else {
                    this.title = `Case Comments (${Math.min(
                        this.numberOfRecords,
                        this.records.length
                    )})`;
                }

                console.log('records ' + JSON.stringify(this.records));
            })
            .catch((error) => {});
    }
    navigateToRelatedList() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Case',
                relationshipApiName: 'CaseComments',
                actionName: 'view'
            }
        });
    }
    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'edit':
                this.handleEditRecord(row);
                break;
            case 'delete':
                this.handleDeleteRecord(row);
                break;
            default:
        }
    }
    handleCreateRecord() {
        const newEditPopup = this.template.querySelector(
            'c-case-related-list-edit-modal'
        );
        newEditPopup.recordId = null;
        newEditPopup.recordName = null;
        newEditPopup.sobjectApiName = 'CaseComment';
        newEditPopup.sobjectLabel = 'Case Comment';
        newEditPopup.caseId = this.recordId;
        newEditPopup.show();
    }

    handleEditRecord(row) {
        const newEditPopup = this.template.querySelector(
            'c-case-related-list-edit-modal'
        );
        newEditPopup.recordId = row.Id;
        newEditPopup.recordName = 'Case Comment';
        newEditPopup.sobjectApiName = 'CaseComment';
        newEditPopup.sobjectLabel = 'Case Comment';
        newEditPopup.caseId = this.recordId;
        newEditPopup.show();
    }

    handleDeleteRecord(row) {
        const newEditPopup = this.template.querySelector(
            'c-case-related-list-delete-modal'
        );
        newEditPopup.recordId = row.Id;
        newEditPopup.recordName = row.Name;
        newEditPopup.sobjectLabel = 'Case Comment';
        newEditPopup.show();
    }

    handleRefreshData() {
        this.fetchCaseComments();
    }
}

import { LightningElement, api, track } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import storeComment from "@salesforce/apex/SP_A_ConsoleController.storeComment";
import updateStepAssignment from "@salesforce/apex/SP_A_ConsoleController.updateStepAssignment";
import log from "@salesforce/apex/SP_A_ConsoleController.log";
import executeStep from "@salesforce/apex/SP_A_ConsoleController.executeStep";
import verifyStep from "@salesforce/apex/SP_A_ConsoleController.verifyStep";
import updateStepStatus from "@salesforce/apex/SP_A_ConsoleController.updateStepStatus";

import restartRunlistSection from "@salesforce/apex/SP_A_ConsoleController.restartRunlistSection";
import updateSectionAssignee from "@salesforce/apex/SP_A_ConsoleController.updateSectionAssignee";
import publishJenkinsStatusEvent from "@salesforce/apex/SP_A_ConsoleController.publishJenkinsStatusEvent";
import getStoredJenkinsLog from "@salesforce/apex/SP_A_ConsoleController.getStoredJenkinsLog";

import { SandpiperHelper } from "c/sp_a_sandpiperHelper";

import * as CONSTANT from "c/sp_a_sandpiperConstants";

const DEFAULT_STEP_STATUS_MAP = {};
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.PENDING] = true;
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.SKIPPED] = false;
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.COMPLETED] = false;
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.AUTOMATED] = false;

export default class SandboxRunlistExecution extends NavigationMixin(
  LightningElement
) {
  utils;

  @api sandbox = {};
  @api selectedStepId = null;

  @track stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

  showUserAssignment = false;
  showValidateModal = false;
  showStepDetailModal = false;
  stepActionProcessing = false;
  showValidationModal = false;

  selectedSection;

  validateResponse = {};

  assigneeContext = {};

  styles = {};

  get selectedAssigneeId() {
    return this.utils.get(this, "step.assigneeId");
  }

  get step() {
    let step = {};
    const steps = this.utils.get(this, "sandbox.runlistExecution.steps") || [];
    steps.forEach((s) => {
      if (s && s.id === this.selectedStepId) {
        step = s;
      }
    });
    return step;
  }

  get hasStep() {
    return this.selectedStepId != null;
  }

  get stepTabs() {
    return this.utils.getStepTabs(
      this.stepRunlistStatusMap,
      this.sandbox.runlistExecution.steps
    );
  }

  get runlistSections() {
    return this.hasStep
      ? this.utils.getRunlistSections(
          this.stepRunlistStatusMap,
          this.sandbox.runlistExecution.steps,
          this.selectedStepId
        )
      : [];
  }

  get hasRunlistSteps() {
    return this.runlistSections && this.runlistSections.length > 0;
  }

  get validateStatusClass() {
    if (this.utils.get(this, "validateResponse.status") === "Verified") {
      return "success";
    }
    return "error";
  }

  get hasError() {
    return (
      this.hasStep &&
      this.utils.get(this, "step.failed") &&
      this.utils.get(this, "step.lastExecutionResponse")
    );
  }

  get validateModalCtx() {
    return {
      title: "Validate Step",
      size: "lg",
      buttons: [CONSTANT.MODAL_BUTTONS.CANCEL],
      onCancel: this.handleValidateModalCancel.bind(this)
    };
  }

  connectedCallback() {
    this.utils = new SandpiperHelper(this);

    if (
      this.sandbox.runlistProgress &&
      this.sandbox.runlistProgress.percentComplete >= 100
    ) {
      const stepRunlistStatusMap =
        JSON.parse(JSON.stringify(this.stepRunlistStatusMap)) || {};
      Object.keys(stepRunlistStatusMap).forEach((key) => {
        stepRunlistStatusMap[key] = true;
      });
      this.stepRunlistStatusMap = stepRunlistStatusMap;
    }

    window.addEventListener("resize", this.initUI.bind(this));
    this.initUI();
  }

  initUI(timeoutMs) {
    const cmp = this;
    setTimeout(function () {
      cmp.utils.setElementHeight("sp-runlist-steps", 25);
    }, timeoutMs || 10);
  }

  handleStepTabChange(e) {
    const stepRunlistStatusMap =
      JSON.parse(JSON.stringify(this.stepRunlistStatusMap)) || {};
    stepRunlistStatusMap[e.currentTarget.dataset.name] = e.target.checked;
    this.stepRunlistStatusMap = stepRunlistStatusMap;
    this.initUI();
  }

  handleStepSelection(e) {
    if (this.utils.get(e, "currentTarget.dataset.id")) {
      this.selectRunlistStep(this.utils.get(e, "currentTarget.dataset.id"));
    }
  }

  selectRunlistStep(stepId) {
    this.selectedStepId = stepId;
  }

  handleAssignSection(e) {
    const sectionName = e.currentTarget.dataset.id;
    this.showUserAssignment = true;
    this.assigneeContext = {
      section: sectionName,
      title: "Select Assignee - " + sectionName,
      selectedId: null
    };
  }

  handleRestartSection(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return;
    }

    const sectionName = e.currentTarget.dataset.id;
    const cmp = this;

    this.utils.showConfirmation(
      `Restart Runlist Section?`,
      `Restart all Runlist Steps in "${sectionName}"? This will reset all steps and begin execution at the first step in the section. Once confirmed, this cannot be undone.`,
      (event) => {
        cmp.stepActionProcessing = true;
        let steps = [];
        restartRunlistSection({
          sandboxId: cmp.sandbox.id,
          section: sectionName
        })
          .then((r) => {
            steps = r;
            return storeComment({
              sandboxId: cmp.sandbox.id,
              runlistId: cmp.sandbox.runlist.id,
              runlistStepId: steps.length > 0 ? steps[0].Id : null,
              section: sectionName,
              comment: cmp.utils.get(event, "detail.textValue")
            });
          })
          .then((r) => {
            return executeStep({
              sandboxId: cmp.sandbox.id,
              stepId: steps.length > 0 ? steps[0].Id : null
            });
          })
          .then((r) => {
            cmp.stepActionProcessing = false;
            cmp.utils.toast(
              "success",
              `Restart Runlist Section`,
              `Restarting "${sectionName}"`
            );
          })
          .catch((e) => {
            cmp.utils.toastError("Restart Runlist Section", e);
          });
      },
      true
    );
  }

  handleStepVerify(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return;
    }

    this.validateResponse = {
      loading: true
    };
    this.showValidateModal = true;

    const stepId = e.currentTarget.dataset.id;

    verifyStep({
      sandboxId: this.sandbox.id,
      stepId: stepId
    })
      .then((r) => {
        this.validateResponse = Object.assign({ loading: false }, r);
      })
      .catch((e) => {
        this.utils.toast(
          "error",
          "Validate Step",
          this.utils.get(e, "body.message")
        );
        this.validateResponse = { loading: false };
        this.showValidateModal = false;
      });
  }

  handleValidateModalCancel() {
    this.validateResponse = {};
    this.showValidateModal = false;
  }

  handleValidateSection(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return;
    }

    this.selectedSection = e.currentTarget.dataset.id;
    this.showValidationModal = true;
  }

  handleSectionValidationCancel() {
    this.showValidationModal = false;
  }

  handleAssigneeCancel() {
    this.showUserAssignment = false;
  }

  handleAssigneeChange(e) {
    const selectedId = e.detail.value;
    this.stepActionProcessing = true;
    this.showUserAssignment = false;

    let method;
    if (this.assigneeContext.section) {
      method = updateSectionAssignee({
        sandboxId: this.sandbox.id,
        section: this.assigneeContext.section,
        userId: selectedId
      });
    } else {
      method = updateStepAssignment({
        sandboxId: this.sandbox.id,
        stepId: this.step.id,
        userId: selectedId
      });
    }

    method
      .then((r) => {
        this.refreshSandbox();
        this.stepActionProcessing = false;
      })
      .catch((e) => {
        this.stepActionProcessing = false;
        this.utils.toastError("Assignee Change", e);
      });
  }

  handleStepAssignment(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return;
    }
    this.showUserAssignment = true;
    this.assigneeContext = {
      section: false,
      title: "Select Assignee - " + this.step.name,
      selectedId: this.selectedAssigneeId
    };
  }

  handleStepManualUpdate() {
    this.showStepDetailModal = true;
  }

  handleStepDetailModalCancel() {
    this.showStepDetailModal = false;
  }

  handleStepDetailModalSubmit(e) {
    this.showStepDetailModal = false;
    this.handleStepStatusChange(
      this.sandbox.id,
      e.detail.id,
      e.detail.status,
      e.detail.comments
    );
  }

  handleShowError(e) {
    let friendlyError = this.step.lastExecutionResponse;

    try {
      const responseObj = JSON.parse(this.step.lastExecutionResponse);

      const lines = [`Error: ${responseObj.message}`];

      if (responseObj.rawResponse) {
        lines.push(`Raw Response:\n${responseObj.rawResponse}`);
      }

      friendlyError = lines.join("\n\n");
    } catch (error) {
      console.error("Error parsing sandbox settings:", error);
    }

    this.utils.openModal({
      title: this.step.name,
      message: friendlyError,
      size: "lg",
      buttons: [CONSTANT.MODAL_BUTTONS.CANCEL]
    });
  }

  showTaskDetails(e) {
    const stepName = e.currentTarget.dataset.name;
    const taskDetails = e.currentTarget.dataset.text;
    const stepId = e.currentTarget.dataset.id;
    this.utils.openModal({
      title: stepName,
      message: taskDetails,
      size: "lg",
      buttons: [
        CONSTANT.MODAL_BUTTONS.CANCEL,
        {
          label: "Completed",
          class: "slds-button slds-button_success",
          event: "onCompleted"
        },
        {
          label: "Failed",
          class: "slds-button slds-button_destructive",
          event: "onFailed"
        }
      ],
      onCompleted: () => {
        this.handleStatus(this.sandbox.id, stepId, "Completed");
        this.utils.closeModal();
      },
      onFailed: () => {
        this.handleStatus(this.sandbox.id, stepId, "Failed");
        this.utils.closeModal();
      }
    });
  }
  @api
  handleStatusApi(sandboxId, stepId, status) {
    this.handleStatus(sandboxId, stepId, status);
  }
  handleStatus(sandboxId, stepId, status) {
    updateStepStatus({
      sandboxId: sandboxId,
      stepId: stepId,
      status: status
    })
      .then((res) => {
        this.refreshSandbox();
      })
      .catch((err) => {
        this.utils.toastError("Step Status Change", err);
      });
  }
  handleStepStatusConfirmation(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return false;
    }

    const stepId = e.currentTarget.dataset.id;
    const status = e.currentTarget.dataset.status;

    const onConfirm = (event) => {
      this.handleStepStatusChange(
        this.sandbox.id,
        stepId,
        status,
        this.utils.get(event, "detail.textValue")
      );
    };

    this.utils.showConfirmation(
      "Update Runlist Step?",
      "Please confirm that you want to update " +
        this.step.name +
        " to " +
        status,
      onConfirm.bind(this),
      true
    );
  }
  @api
  handleStepStatusChangeApi(sandboxId, stepId, status, comment) {
    this.handleStepStatusChange(sandboxId, stepId, status, comment);
  }
  handleStepStatusChange(sandboxId, stepId, status, comment) {
    this.stepActionProcessing = true;

    updateStepStatus({
      sandboxId: sandboxId,
      stepId: stepId,
      status: status
    })
      .then((res) => {
        this.handelRecordTouched();
        this.executionStatus = res;
        return storeComment({
          sandboxId: sandboxId,
          runlistId: this.sandbox.runlist.id,
          runlistStepId: stepId,
          section: this.step.name,
          comment: comment
        });
      })
      .then((res) => {
        this.stepActionProcessing = false;
        this.refreshSandbox();
      })
      .catch((err) => {
        this.stepActionProcessing = false;
        this.utils.toastError("Step Status Change", err);
      });
  }

  handleJenkinsStatus(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return false;
    }
    const stepId = e.currentTarget.dataset.id;
    publishJenkinsStatusEvent({
      stepId: stepId,
      sandboxId: this.sandbox.id
    })
      .then(() => {
        this.utils.toast(
          "success",
          "Status request submitted",
          "If the Jenkins job has completed or failed, the step will be updated. You may also check the log for more details."
        );
      })
      .catch((e) => {
        this.utils.toastError("Get Jenkins Status", e);
      });
  }

  handleViewJenkinsLog(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return false;
    }
    this.stepActionProcessing = true;
    const stepId = e.currentTarget.dataset.id;
    getStoredJenkinsLog({
      stepId: stepId
    })
      .then((log) => {
        const cmp = this;
        this.utils.openModal({
          title: log.fileName,
          subtitle: `Updated : ${log.lastModifiedDate}`,
          message: log.text,
          size: "xlg",
          buttons: [
            {
              label: "Download",
              class: "slds-button slds-button_brand",
              event: "onDownload"
            },
            CONSTANT.MODAL_BUTTONS.CANCEL
          ],
          onDownload: (e) => {
            cmp.handleDownloadJenkinsLog(log.fileId);
          }
        });
      })
      .catch((e) => {
        this.utils.toastError("View Jenkins Log", e);
      })
      .finally(() => {
        this.stepActionProcessing = false;
      });
  }

  handleDownloadJenkinsLog(fileId) {
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId: fileId,
        actionName: "view"
      }
    });
  }

  handleStepExecution(e) {
    if (e.currentTarget.dataset.enabled !== "true") {
      return false;
    }

    const stepId = e.currentTarget.dataset.id;

    const onConfirm = (event) => {
      this.stepActionProcessing = true;

      log({
        type: "DEBUG",
        sandboxId: this.sandbox.id,
        stepId: this.step.id,
        message: "Starting " + this.step.name
      })
        .then((r) => {
          return updateStepStatus({
            sandboxId: this.sandbox.id,
            stepId: stepId,
            status: CONSTANT.LABELS.IN_PROGRESS
          });
        })
        .then((r) => {
          return executeStep({
            sandboxId: this.sandbox.id,
            stepId: stepId
          });
        })
        .then((res) => {
          this.handelRecordTouched();
          if (res.statusCode < 300) {
            storeComment({
              sandboxId: this.sandbox.id,
              runlistId: this.sandbox.runlist.id,
              runlistStepId: this.step.id,
              section: this.step.name,
              comment: this.utils.get(event, "detail.textValue")
            });
          } else if (res.statusCode) {
            this.utils.toastError("Step Execution", res.message);
          }
          this.stepActionProcessing = false;
        })
        .catch((err) => {
          this.stepActionProcessing = false;
          this.utils.toastError("Step Execution", err);
        });
    };

    this.utils.showConfirmation(
      "Start Runlist Step?",
      "Please confirm that you want to start " + this.step.name,
      onConfirm,
      true
    );
  }

  refreshSandbox(recalculateProgress) {
    this.dispatchEvent(
      new CustomEvent("refreshsandbox", {
        detail: recalculateProgress
      })
    );
  }

  handelRecordTouched() {
    this.dispatchEvent(new CustomEvent("recordtouched"));
  }

  navigateToRecordDetailPage(e) {
    this.utils.openRecord(e.currentTarget.dataset.id);
  }
}

import { createElement } from 'lwc';
import SandboxRunlistExecution from 'c/sp_a_sandboxRunlistExecution';
import SPAModal from 'c/sp_a_modal';
import { NavigationMixin } from 'lightning/navigation';
import updateStepStatus from '@salesforce/apex/SP_A_ConsoleController.updateStepStatus';
import publishJenkinsStatusEvent from '@salesforce/apex/SP_A_ConsoleController.publishJenkinsStatusEvent';
import getStoredJenkinsLog from '@salesforce/apex/SP_A_ConsoleController.getStoredJenkinsLog';
import logTest from '@salesforce/apex/SP_A_ConsoleController.log';

import * as CONSTANT from 'c/sp_a_sandpiperConstants';
import * as MOCK from './sp_a_sandboxRunlistExecutionMockData.js';

const DEFAULT_STEP_STATUS_MAP = {};
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.PENDING] = true;
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.SKIPPED] = false;
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.COMPLETED] = false;
DEFAULT_STEP_STATUS_MAP[CONSTANT.LABELS.AUTOMATED] = false;

jest.mock(
    '@salesforce/apex/SP_A_ConsoleController.log',
    () => {
        return {
            default: jest.fn()
        };
    },
    { virtual: true }
);
jest.mock(
    '@salesforce/apex/SP_A_ConsoleController.getStoredJenkinsLog',
    () => {
        return {
            default: jest.fn()
        };
    },
    { virtual: true }
);
// Mocking imperative Apex method call
jest.mock(
    '@salesforce/apex/SP_A_ConsoleController.updateStepStatus',
    () => {
        return {
            default: jest.fn()
        };
    },
    { virtual: true }
);
jest.mock(
    '@salesforce/apex/SP_A_ConsoleController.publishJenkinsStatusEvent',
    () => {
        return {
            default: jest.fn()
        };
    },
    { virtual: true }
);

// Mocking the Apex methods
jest.mock(
    '@salesforce/apex/SP_A_ConsoleController',
    () => ({
        storeComment: jest.fn(),
        updateStepAssignment: jest.fn(),
        log: jest.fn(),
        executeStep: jest.fn(),
        verifyStep: jest.fn(),
        updateStepStatus: jest.fn(),
        restartRunlistSection: jest.fn(),
        updateSectionAssignee: jest.fn(),
        publishJenkinsStatusEvent: jest.fn(),
        getStoredJenkinsLog: jest.fn()
    }),
    { virtual: true }
);
jest.mock(
    '@salesforce/label/c.SP_A_PENDING',
    () => {
        return { default: 'Pending' };
    },
    { virtual: true }
);
jest.mock(
    '@salesforce/label/c.SP_A_SKIPPED',
    () => {
        return { default: 'Skipped' };
    },
    { virtual: true }
);
jest.mock(
    '@salesforce/label/c.SP_A_COMPLETED',
    () => {
        return { default: 'Completed' };
    },
    { virtual: true }
);
jest.mock(
    '@salesforce/label/c.SP_A_AUTOMATED',
    () => {
        return { default: 'Automated' };
    },
    { virtual: true }
);
jest.mock(
    '@salesforce/label/c.SP_A_NOT_APPLICABLE_BY_TYPE',
    () => {
        return { default: 'Not Applicable by Type' };
    },
    { virtual: true }
);

describe('c-sp_a_sandboxRunlistExecutions', () => {
    beforeAll(() => {
        // We use fake timers as setTimeout is used in the JavaScript file.
        jest.useFakeTimers();
    });
    afterEach(() => {
        // Prevent data saved on mocks from leaking between tests
        jest.clearAllMocks();
    });

    function flushPromises() {
        // eslint-disable-next-line no-undef
        return new Promise((resolve) => setImmediate(resolve));
    }

    it('should initialize with default values', () => {
        const element = createElement('c-sp_a_sandbox-runlist-execution', {
            is: SandboxRunlistExecution
        });
        element.sandbox = MOCK.DEFAULT_SANDBOX;

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);

        // Assert default values

        expect(element.selectedStepId).toBeNull();

        expect(element.showUserAssignment).toBeFalsy();
        expect(element.showValidateModal).toBeFalsy();
        expect(element.showStepDetailModal).toBeFalsy();
        expect(element.stepActionProcessing).toBeFalsy();
        expect(element.showValidationModal).toBeFalsy();
        expect(element.selectedSection).toBeUndefined();
    });

    it('should update stepRunlistStatusMap on handleStepTabChange', () => {
        updateStepStatus.mockResolvedValue(MOCK.APEX_SUCCESS);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.blue');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[0].children[0].click();
            element.handleStatusApi('a06Ot00000AjFZqIAN', 'a04Ot000001gkQvIAI', 'Completed');
            const APEX_PARAMETERS = {
                sandboxId: 'a06Ot00000AjFZqIAN',
                stepId: 'a04Ot000001gkQvIAI',
                status: 'Completed'
            };
            return flushPromises().then(() => {
                // Validate parameters of mocked Apex call
                expect(updateStepStatus.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
            });
        }
    });
    it('updateStepStatus apex call rejected', () => {
        updateStepStatus.mockRejectedValue(MOCK.APEX_ERROR);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.blue');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[0].children[0].click();
            element.handleStatusApi('a06Ot00000AjFZqIAN', 'a04Ot000001gkQvIAI', 'Completed');
            const APEX_PARAMETERS = {
                sandboxId: 'a06Ot00000AjFZqIAN',
                stepId: 'a04Ot000001gkQvIAI',
                status: 'Completed'
            };
            return flushPromises().then(() => {
                // Validate parameters of mocked Apex call
                expect(updateStepStatus.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
            });
        }
    });

    it('handleStepStatusConfirmation onclick', () => {
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.orange');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[0].children[0].click();
        }
    });

    it('handleStepDetailModalSubmit to be owkred on', () => {
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();

        element.dispatchEvent(new CustomEvent('submit'), {
            detail: {
                id: 'a04Ot000001gkQvIAI',
                status: 'Completed',
                comments: 'testing'
            }
        });
    });
    it('handleJenkinsStatus onclick success', () => {
        publishJenkinsStatusEvent.mockResolvedValue(MOCK.APEX_SUCCESS);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.primary');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[0].children[0].click();
            const APEX_PARAMETERS = {
                stepId: 'a04Ot000001gkQvIAI',
                sandboxId: 'a06Ot00000AjFZqIAN'
            };
            return flushPromises().then(() => {
                // Validate parameters of mocked Apex call
                expect(publishJenkinsStatusEvent.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
            });
        }
    });
    it('handleJenkinsStatus onclick failure', () => {
        publishJenkinsStatusEvent.mockRejectedValue(MOCK.APEX_ERROR);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.primary');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[0].children[0].click();
            const APEX_PARAMETERS = {
                stepId: 'a04Ot000001gkQvIAI',
                sandboxId: 'a06Ot00000AjFZqIAN'
            };
            return flushPromises().then(() => {
                // Validate parameters of mocked Apex call
                expect(publishJenkinsStatusEvent.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
            });
        }
    });
    it('handleViewJenkinsLog onclick success', () => {
        getStoredJenkinsLog.mockResolvedValue(MOCK.APEX_JENKINS_SUCCESS);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.primary');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[1].children[0].click();
            const APEX_PARAMETERS = {
                stepId: 'a04Ot000001gkQvIAI'
            };
            return flushPromises().then(() => {
                // Validate parameters of mocked Apex call
                expect(getStoredJenkinsLog.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
            });
        }
    });
    it('handleViewJenkinsLog onclick failure', () => {
        getStoredJenkinsLog.mockRejectedValue(MOCK.APEX_ERROR);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        const taskDetailsButtons = element.shadowRoot.querySelectorAll('div.sp-icon-btn.primary');
        console.log(taskDetailsButtons.length);
        if (taskDetailsButtons && taskDetailsButtons.length) {
            taskDetailsButtons[1].children[0].click();
            const APEX_PARAMETERS = {
                stepId: 'a04Ot000001gkQvIAI'
            };
            return flushPromises().then(() => {
                // Validate parameters of mocked Apex call
                expect(getStoredJenkinsLog.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
            });
        }
    });
    it('handleStepStatusChange success', () => {
        updateStepStatus.mockResolvedValue(MOCK.APEX_SUCCESS);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        element.handleStepStatusChangeApi('a06Ot00000AjFZqIAN', 'a04Ot000001gkQvIAI', 'Completed');
        const APEX_PARAMETERS = {
            sandboxId: 'a06Ot00000AjFZqIAN',
            stepId: 'a04Ot000001gkQvIAI',
            status: 'Completed'
        };
        return flushPromises().then(() => {
            // Validate parameters of mocked Apex call
            expect(updateStepStatus.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
        });
    });
    it('handleStepStatusChange failure', () => {
        updateStepStatus.mockRejectedValue(MOCK.APEX_ERROR);
        const element = createElement('c-sp_a_sandbox-runlist-executions', {
            is: SandboxRunlistExecution
        });

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;
        element.sandbox = MOCK.DEFAULT_SANDBOX_COMPLETED;
        element.selectedStepId = 'a04Ot000001gkQvIAI';

        element.stepRunlistStatusMap = DEFAULT_STEP_STATUS_MAP;

        document.body.appendChild(element);
        // Run all fake timers.
        jest.runOnlyPendingTimers();
        element.handleStepStatusChangeApi('a06Ot00000AjFZqIAN', 'a04Ot000001gkQvIAI', 'Completed');
        const APEX_PARAMETERS = {
            sandboxId: 'a06Ot00000AjFZqIAN',
            stepId: 'a04Ot000001gkQvIAI',
            status: 'Completed'
        };
        return flushPromises().then(() => {
            // Validate parameters of mocked Apex call
            expect(updateStepStatus.mock.calls[0][0]).toEqual(APEX_PARAMETERS);
        });
    });
});

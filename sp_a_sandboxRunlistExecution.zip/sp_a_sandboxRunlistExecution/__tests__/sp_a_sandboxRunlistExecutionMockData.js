const DEFAULT_SANDBOX = {
    uiContext: {
        inProgress: true
    },
    runlistProgress: {
        percentComplete: 100
    },
    runlistExecution: {
        steps: [{ name: 'test' }]
    }
};
const DEFAULT_SANDBOX_COMPLETED = {
    adminApproval: 0,
    authenticated: true,
    caseCreatedDate: '7/5/2024 2:06 PM PDT',
    caseRecord: {
        hasValue: true,
        id: '500Ot00000AVNnNIAX',
        label: '00001026',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/500Ot00000AVNnNIAX'
    },
    copyFrom: {
        hasValue: false
    },
    defaultRunlistSettings: {
        autoCreateSandboxEnvironmentRecords: false,
        autoExecuteAutomatedRunlistSteps: true,
        autoGrantAssigneesSandboxAccess: false,
        autoSetNextStepAsReady: false,
        autoUpdateSandboxEnvironmentRecords: false,
        copyNewProductionUsersToSandbox: true,
        sendNotifications: true
    },
    id: 'a06Ot00000AjFZqIAN',
    lastModifiedBy: {
        hasValue: true,
        id: '005Ot0000091qqmIAA',
        label: 'User User',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
    },
    lastModifiedDate: '7/5/2024 5:56 PM PDT',
    name: 'DEV2',
    originalSequence: 2,
    parentOrg: {
        hasValue: true,
        id: 'a02Ot00000840hZIAQ',
        label: 'Test Parent Org',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/a02Ot00000840hZIAQ'
    },
    requestor: {
        hasValue: true,
        id: '005Ot0000091qqmIAA',
        label: 'User User',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
    },
    runlist: {
        hasValue: true,
        id: 'a05Ot000009HTlBIAW',
        label: '1 - DEV2',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/a05Ot000009HTlBIAW'
    },
    runlistExecution: {
        currentStage: 'Post Deployment',
        currentStep: {
            assigneeId: '005Ot0000091qqmIAA',
            assigneeName: 'User User',
            automated: false,
            failed: false,
            id: 'a04Ot000001gkQvIAI',
            lastModifiedBy: {
                hasValue: true,
                id: '005Ot0000091qqmIAA',
                label: 'User User',
                url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
            },
            lastModifiedDate: '7/8/2024 10:46 AM PDT',
            name: 'STEP5',
            order: 3,
            section: 'Post Deployment',
            showAssigneeChange: false,
            showComplete: false,
            showGetJenkinsLog: true,
            showGetJenkinsStatus: true,
            showPause: true,
            showPlay: true,
            showRetry: true,
            showSkip: false,
            showValidate: true,
            status: 'Completed',
            validated: false
        },
        readyToRelease: true,
        stages: [
            {
                id: 'Pre Deployment',
                totalSteps: 2
            },
            {
                id: 'Post Deployment',
                totalSteps: 3
            }
        ],
        steps: [
            {
                assigneeId: '005Ot0000091qqmIAA',
                assigneeName: 'User User',
                automated: true,
                failed: false,
                id: 'a04Ot000001gkQrIAI',
                lastModifiedBy: {
                    hasValue: true,
                    id: '005Ot0000091qqmIAA',
                    label: 'User User',
                    url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
                },
                lastModifiedDate: '7/8/2024 11:43 AM PDT',
                name: 'STEP1',
                order: 1,
                section: 'Pre Deployment',
                showAssigneeChange: false,
                showComplete: false,
                showGetJenkinsLog: true,
                showGetJenkinsStatus: true,
                showPause: true,
                showPlay: true,
                showRetry: true,
                showSkip: false,
                showValidate: true,
                status: 'Completed',
                validated: false
            },
            {
                assigneeId: '005Ot0000091qqmIAA',
                assigneeName: 'User User',
                automated: true,
                failed: false,
                id: 'a04Ot000001gkQsIAI',
                lastModifiedBy: {
                    hasValue: true,
                    id: '005Ot0000091qqmIAA',
                    label: 'User User',
                    url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
                },
                lastModifiedDate: '7/8/2024 10:45 AM PDT',
                name: 'STEP2',
                order: 2,
                section: 'Pre Deployment',
                showAssigneeChange: false,
                showComplete: false,
                showGetJenkinsLog: true,
                showGetJenkinsStatus: true,
                showPause: true,
                showPlay: true,
                showRetry: true,
                showSkip: false,
                showValidate: true,
                status: 'Completed',
                validated: false
            },
            {
                assigneeId: '005Ot0000091qqmIAA',
                assigneeName: 'User User',
                automated: true,
                failed: false,
                id: 'a04Ot000001gkQtIAI',
                lastModifiedBy: {
                    hasValue: true,
                    id: '005Ot0000091qqmIAA',
                    label: 'User User',
                    url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
                },
                lastModifiedDate: '7/7/2024 9:10 PM PDT',
                name: 'STEP3',
                order: 3,
                section: 'Post Deployment',
                showAssigneeChange: false,
                showComplete: false,
                showGetJenkinsLog: true,
                showGetJenkinsStatus: true,
                showPause: true,
                showPlay: true,
                showRetry: true,
                showSkip: false,
                showValidate: true,
                status: 'Completed',
                validated: false
            },
            {
                assigneeId: '005Ot0000091qqmIAA',
                assigneeName: 'User User',
                automated: false,
                failed: false,
                id: 'a04Ot000001gkQuIAI',
                lastModifiedBy: {
                    hasValue: true,
                    id: '005Ot0000091qqmIAA',
                    label: 'User User',
                    url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
                },
                lastModifiedDate: '7/8/2024 10:46 AM PDT',
                name: 'STEP4',
                order: 3,
                section: 'Post Deployment',
                showAssigneeChange: false,
                showComplete: false,
                showGetJenkinsLog: true,
                showGetJenkinsStatus: true,
                showPause: true,
                showPlay: true,
                showRetry: true,
                showSkip: false,
                showValidate: true,
                status: 'Completed',
                validated: false
            },
            {
                assigneeId: '005Ot0000091qqmIAA',
                assigneeName: 'User User',
                automated: false,
                failed: false,
                id: 'a04Ot000001gkQvIAI',
                lastModifiedBy: {
                    hasValue: true,
                    id: '005Ot0000091qqmIAA',
                    label: 'User User',
                    url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
                },
                lastModifiedDate: '7/8/2024 10:46 AM PDT',
                name: 'STEP5',
                order: 3,
                section: 'Post Deployment',
                showAssigneeChange: false,
                showComplete: false,
                showGetJenkinsLog: true,
                showGetJenkinsStatus: true,
                showPause: true,
                showPlay: true,
                showRetry: true,
                showSkip: false,
                showValidate: true,
                status: 'Completed',
                validated: false
            }
        ]
    },
    runlistProgress: {
        completed: true,
        completedSteps: 5,
        percentComplete: 100,
        stageProgressMap: {
            'Pre Deployment': {
                completedSteps: 2,
                failedSteps: 0,
                label: 'Pre Deployment (2)',
                name: 'Pre Deployment',
                order: 1,
                totalSteps: 2
            },
            'Post Deployment': {
                completedSteps: 3,
                failedSteps: 0,
                label: 'Post Deployment (3)',
                name: 'Post Deployment',
                order: 3,
                totalSteps: 3
            }
        },
        totalSteps: 5
    },
    runlistSettings: {
        autoExecuteAutomatedRunlistSteps: true,
        autoGrantAssigneesSandboxAccess: false,
        autoSetNextStepAsReady: false,
        copyNewProductionUsersToSandbox: true,
        sendNotifications: true
    },
    runlistTemplate: {
        hasValue: true,
        id: 'a05Ot000009GkeWIAS',
        label: 'Template1',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/a05Ot000009GkeWIAS'
    },
    runlistTemplates: [],
    sandboxProcess: {
        completed: true,
        failed: false,
        linkSandbox: false,
        percentComplete: 100,
        startDate: 'Queued',
        started: false,
        status: 'Requested'
    },
    sequence: 2,
    status: 'In Progress',
    type: {
        hasValue: true,
        id: 'a08Ot00000DzG8QIAV',
        label: 'Developer',
        url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/a08Ot00000DzG8QIAV'
    },
    uiContext: {
        active: false,
        copyCompleted: true,
        decommissioned: false,
        inProgress: true,
        paused: false,
        ready: false,
        requested: false,
        requiresClone: false,
        showConfiguration: false,
        showRemoveFromQueue: false,
        showRunlistExecution: true,
        showStartCopy: false,
        showStartRunlist: false,
        unlinked: false
    }
};
const APEX_ERROR = {};
// Sample data for imperative Apex call
const APEX_SUCCESS = {
    currentStage: 'Post Deployment',
    currentStep: {
        assigneeId: '005Ot0000091qqmIAA',
        assigneeName: 'User User',
        automated: false,
        failed: false,
        id: 'a04Ot000001gkQvIAI',
        lastModifiedBy: {
            hasValue: true,
            id: '005Ot0000091qqmIAA',
            label: 'User User',
            url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
        },
        lastModifiedDate: '7/8/2024 11:58 PM PDT',
        name: 'STEP5',
        order: 3,
        section: 'Post Deployment',
        showAssigneeChange: false,
        showComplete: false,
        showGetJenkinsLog: true,
        showGetJenkinsStatus: true,
        showPause: true,
        showPlay: true,
        showRetry: true,
        showSkip: false,
        showValidate: true,
        status: 'Completed',
        validated: false
    },
    readyToRelease: true,
    stages: [
        {
            id: 'Pre Deployment',
            totalSteps: 2
        },
        {
            id: 'Post Deployment',
            totalSteps: 3
        }
    ],
    steps: [
        {
            assigneeId: '005Ot0000091qqmIAA',
            assigneeName: 'User User',
            automated: true,
            failed: false,
            id: 'a04Ot000001gkQrIAI',
            lastModifiedBy: {
                hasValue: true,
                id: '005Ot0000091qqmIAA',
                label: 'User User',
                url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
            },
            lastModifiedDate: '7/8/2024 11:43 AM PDT',
            name: 'STEP1',
            order: 1,
            section: 'Pre Deployment',
            showAssigneeChange: false,
            showComplete: false,
            showGetJenkinsLog: true,
            showGetJenkinsStatus: true,
            showPause: true,
            showPlay: true,
            showRetry: true,
            showSkip: false,
            showValidate: true,
            status: 'Completed',
            validated: false
        },
        {
            assigneeId: '005Ot0000091qqmIAA',
            assigneeName: 'User User',
            automated: true,
            failed: false,
            id: 'a04Ot000001gkQsIAI',
            lastModifiedBy: {
                hasValue: true,
                id: '005Ot0000091qqmIAA',
                label: 'User User',
                url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
            },
            lastModifiedDate: '7/8/2024 10:45 AM PDT',
            name: 'STEP2',
            order: 2,
            section: 'Pre Deployment',
            showAssigneeChange: false,
            showComplete: false,
            showGetJenkinsLog: true,
            showGetJenkinsStatus: true,
            showPause: true,
            showPlay: true,
            showRetry: true,
            showSkip: false,
            showValidate: true,
            status: 'Completed',
            validated: false
        },
        {
            assigneeId: '005Ot0000091qqmIAA',
            assigneeName: 'User User',
            automated: true,
            failed: false,
            id: 'a04Ot000001gkQtIAI',
            lastModifiedBy: {
                hasValue: true,
                id: '005Ot0000091qqmIAA',
                label: 'User User',
                url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
            },
            lastModifiedDate: '7/7/2024 9:10 PM PDT',
            name: 'STEP3',
            order: 3,
            section: 'Post Deployment',
            showAssigneeChange: false,
            showComplete: false,
            showGetJenkinsLog: true,
            showGetJenkinsStatus: true,
            showPause: true,
            showPlay: true,
            showRetry: true,
            showSkip: false,
            showValidate: true,
            status: 'Completed',
            validated: false
        },
        {
            assigneeId: '005Ot0000091qqmIAA',
            assigneeName: 'User User',
            automated: false,
            failed: false,
            id: 'a04Ot000001gkQuIAI',
            lastModifiedBy: {
                hasValue: true,
                id: '005Ot0000091qqmIAA',
                label: 'User User',
                url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
            },
            lastModifiedDate: '7/8/2024 10:46 AM PDT',
            name: 'STEP4',
            order: 3,
            section: 'Post Deployment',
            showAssigneeChange: false,
            showComplete: false,
            showGetJenkinsLog: true,
            showGetJenkinsStatus: true,
            showPause: true,
            showPlay: true,
            showRetry: true,
            showSkip: false,
            showValidate: true,
            status: 'Completed',
            validated: false
        },
        {
            assigneeId: '005Ot0000091qqmIAA',
            assigneeName: 'User User',
            automated: false,
            failed: false,
            id: 'a04Ot000001gkQvIAI',
            lastModifiedBy: {
                hasValue: true,
                id: '005Ot0000091qqmIAA',
                label: 'User User',
                url: 'https://drive-site-3374-dev-ed.scratch.my.salesforce.com/005Ot0000091qqmIAA'
            },
            lastModifiedDate: '7/8/2024 11:58 PM PDT',
            name: 'STEP5',
            order: 3,
            section: 'Post Deployment',
            showAssigneeChange: false,
            showComplete: false,
            showGetJenkinsLog: true,
            showGetJenkinsStatus: true,
            showPause: true,
            showPlay: true,
            showRetry: true,
            showSkip: false,
            showValidate: true,
            status: 'Completed',
            validated: false
        }
    ]
};

const APEX_JENKINS_SUCCESS = {
    fileName: 'testing',
    text: 'testing',
    lastModifiedDate: '2024-07-22',
    fileId: 'testing'
};

export { DEFAULT_SANDBOX, DEFAULT_SANDBOX_COMPLETED, APEX_ERROR, APEX_SUCCESS, APEX_JENKINS_SUCCESS };

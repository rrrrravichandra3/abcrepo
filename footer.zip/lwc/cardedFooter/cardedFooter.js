import { LightningElement } from 'lwc';

export default class CardedFooter extends LightningElement {
    showSubscribe = false;
    handleSubscribe() {
        this.showSubscribe = true;
    }
    closeSubscribe() {
        this.showSubscribe = false;
    }
}
import { LightningElement } from 'lwc';

export default class SubscribeNowModal extends LightningElement {}